# Opnet_Faucet DApp v2 — Full Setup Guide

## Architecture

```
opnet-faucet-v2/
├── backend/
│   ├── server.js       ← Secure API: 24h enforcement, TX broadcast, block mining
│   └── package.json
└── frontend/
    └── public/
        └── index.html  ← DApp UI: real OP_NET wallet detection, no fake logic
```

---

## Step 1 — Bitcoin Regtest Node

```bash
# Start Bitcoin Core in regtest mode
bitcoind \
  -regtest \
  -rpcuser=rpcuser \
  -rpcpassword=rpcpassword \
  -rpcport=8332 \
  -server \
  -daemon

# Create and load faucet wallet
bitcoin-cli -regtest createwallet "faucet"
bitcoin-cli -regtest loadwallet "faucet"

# Get treasury address (save this!)
TREASURY=$(bitcoin-cli -regtest getnewaddress "treasury")
echo "Treasury: $TREASURY"

# Mine 101 blocks to activate and fund treasury (regtest coinbase)
bitcoin-cli -regtest generatetoaddress 101 $TREASURY

# Verify balance
bitcoin-cli -regtest getbalance
```

---

## Step 2 — Deploy OP_NET Tokens

```bash
# Install OP_NET CLI (adjust per official OP_NET docs)
npm install -g @opnet/cli

# Deploy OPNET token
opnet deploy-token \
  --network regtest \
  --rpc http://localhost:8332 \
  --name "Opnet" \
  --symbol "OPNET" \
  --supply 1000000000 \
  --wallet $TREASURY

# Deploy MOTO token
opnet deploy-token \
  --network regtest \
  --name "Moto Test" \
  --symbol "MOTO" \
  --supply 1000000000 \
  --wallet $TREASURY

# Deploy RBTC token  
opnet deploy-token \
  --network regtest \
  --name "RBTC" \
  --symbol "RBTC" \
  --supply 1000000000 \
  --wallet $TREASURY

# Mine block to confirm deployments
bitcoin-cli -regtest generatetoaddress 1 $TREASURY
```

Save the **contract addresses** printed after each deployment.

---

## Step 3 — Configure Backend

Open `backend/server.js` and update the `CONFIG` block at the top:

```js
const CONFIG = {
  network:         'regtest',
  bitcoinRpcUrl:   'http://127.0.0.1:8332',
  bitcoinRpcUser:  'rpcuser',      // match your bitcoind config
  bitcoinRpcPass:  'rpcpassword',  // match your bitcoind config
  walletName:      'faucet',       // wallet you created in Step 1
  tokens: {
    OPNET: {
      contractAddress: 'PASTE_OPNET_CONTRACT_ADDRESS',  // ← from Step 2
      ...
    },
    MOTO: {
      contractAddress: 'PASTE_MOTO_CONTRACT_ADDRESS',   // ← from Step 2
      ...
    },
    RBTC: {
      contractAddress: 'PASTE_RBTC_CONTRACT_ADDRESS',   // ← from Step 2
      ...
    }
  },
  treasuryAddress: 'PASTE_TREASURY_ADDRESS',  // ← $TREASURY from Step 1
};
```

Then integrate the actual OP_NET SDK transfer in the `broadcastOpnetTransfer()` function:

```js
// Replace placeholder with real SDK call:
import { OpNetProvider } from '@opnet/sdk';
const provider = new OpNetProvider(CONFIG.bitcoinRpcUrl, 'regtest');
const contract = provider.getContract(token.contractAddress, faucetPrivateKey);
const txid = await contract.transfer(toAddress, BigInt(amount * 10**token.decimals));
```

---

## Step 4 — Start Backend

```bash
cd backend
npm install
npm start
# → Server at http://localhost:3000
```

Verify it works:
```bash
curl http://localhost:3000/api/health
```

Expected response:
```json
{
  "status": "ok",
  "network": "regtest",
  "rpcOk": true,
  "blockCount": 101,
  "tokens": ["OPNET", "MOTO", "RBTC"]
}
```

---

## Step 5 — OP_NET Browser Extension

1. Install the OP_NET browser extension
2. Open extension → Settings → Network → **Switch to Regtest**
3. Import or create a test wallet
4. Open `http://localhost:3000`
5. Click **CONNECT OP_NET WALLET** → Extension popup appears → Approve

---

## Step 6 — Test a Claim

1. Click any token's **CLAIM** button
2. Backend checks 24h cooldown
3. Backend broadcasts TX to regtest
4. Backend mines 1 block (auto-confirmation)
5. Backend waits for 1 confirmation
6. Frontend shows TX hash + success toast
7. Cooldown timer starts (24h)

---

## Claim Security Model

| Attack | Protection |
|---|---|
| Page refresh | Cooldowns stored in server memory (not browser) |
| New browser / incognito | Cooldown keyed to `wallet_address::token_symbol` |
| DevTools fetch manipulation | Server validates timestamp independently |
| Frontend bypass | Frontend only displays — never controls rules |
| Double-submit race | Timestamp stored only after confirmed TX |

---

## API Reference

### `GET /api/health`
Returns RPC status, block count, network info.

### `GET /api/tokens`
Returns token list with contract addresses and claim amounts.

### `GET /api/status/:wallet`
Returns per-token cooldown status for a given wallet address.

```json
{
  "wallet": "bcrt1q...",
  "status": {
    "OPNET": {
      "canClaim": false,
      "cooldownRemainingMs": 82800000,
      "cooldownRemaining": "23:00:00",
      "nextClaimAt": "2025-01-02T12:00:00.000Z"
    }
  }
}
```

### `GET /api/balances/:wallet`
Returns token balances for wallet (integrate OP_NET SDK per token).

### `POST /api/claim`
```json
{ "wallet": "bcrt1q...", "tokenSymbol": "OPNET" }
```
Returns `200` on success, `429` if cooldown active, `500` on TX failure.

---

## Common Errors

### "OP_NET wallet not detected"
- Install the OP_NET browser extension
- Reload the page
- Check the extension is enabled for localhost

### "Popup does not appear"
- Extension is on wrong network — switch to Regtest
- Extension needs permission for this site
- Try disabling other wallet extensions that might conflict

### "Transaction stuck / balance unchanged"
- You must mine a block after each TX on regtest
- The backend does this automatically via `generatetoaddress`
- If bitcoind is not running, start it (Step 1)

### "Treasury insufficient balance"
- Run Step 2 again to deploy and mint tokens to treasury
- Verify with: `bitcoin-cli -regtest getbalance`

### "RPC connection refused"
- Start bitcoind: `bitcoind -regtest -daemon`
- Check `-rpcuser` and `-rpcpassword` match CONFIG

---

## Production Checklist

- [ ] Replace in-memory `claimStore` with Redis or SQLite
- [ ] Add rate limiting middleware (`express-rate-limit`)
- [ ] Use environment variables (`.env`) for RPC credentials
- [ ] Add HTTPS / reverse proxy (nginx)
- [ ] Implement real OP_NET SDK `transfer()` call
- [ ] Add wallet signing verification (prove ownership)
- [ ] Monitor treasury balance and alert when low
